from pathlib import Path
import os
import shutil
def log_ok(msg):   print(f"[OK] {msg}",   flush=True)
def log_info(msg): print(f"[INFO] {msg}", flush=True)
def log_warn(msg): print(f"[WARN] {msg}", flush=True)
def log_err(msg):  print(f"[ERR] {msg}",  flush=True) 

SCRIPT_DIR = Path(__file__).resolve().parent
APP_BASE   = Path(os.environ.get("APP_BASE", SCRIPT_DIR.parent)).resolve()
DOCS_DIR   = Path(os.environ.get("DOCS_DIR", APP_BASE / "docs")).resolve()

FILES_TO_DELETE = [
    DOCS_DIR / "updated_file.xlsx",
    DOCS_DIR / "updated_prices.xlsx",
    DOCS_DIR / "updated_tvl.xlsx",
    DOCS_DIR / "sorted_tvl.xlsx",
    DOCS_DIR / "sorted_tvl.xlsx.bak",
    DOCS_DIR / "validated.xlsx",
]

def main():
    failed = False

    for p in FILES_TO_DELETE:
        try:
            Path(p).unlink(missing_ok=True)  
        except IsADirectoryError:
            try:
                shutil.rmtree(p, ignore_errors=False)
            except Exception:
                failed = True
        except Exception:
            failed = True

    if failed:
        log_warn("Some cache files could not be removed. This can be ignored.")
    else:
        log_ok("Cache files cleared successfully.")

if __name__ == "__main__":
    main()
